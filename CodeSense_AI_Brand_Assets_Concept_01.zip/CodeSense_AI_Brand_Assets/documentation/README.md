# CodeSense AI — Brand Assets (Concept 01)

This package contains export-ready derivatives of the approved CodeSense AI icon concept.

## Master
- `master/codesense-ai-logo-master.png` — original approved generated artwork (1254 × 1254 px).

## Web
- `web/icons/favicon.ico` — multi-resolution favicon.
- `web/icons/favicon-*.png` — small PNG favicon sizes.
- `web/icons/apple-touch-icon.png` — 180 × 180.
- `web/icons/icon-192x192.png` and `icon-512x512.png` — PWA icons.
- `web/manifest.webmanifest` — PWA manifest example.

## Android
- `android/legacy/` — square launcher icon exports at multiple sizes.
- These are legacy/full-background launcher images. They are NOT transparent adaptive-icon foreground assets.

## Social
- `social/profile-avatar-1024.png` — square profile/avatar export.
- `social/og-image-1200x630.jpg` — Open Graph/social preview image.

## Important implementation notes
- The artwork is a dark-background square icon. Transparent-background variants have intentionally not been fabricated.
- No wordmark, typography lockup, monochrome logo, SVG/vector master, or adaptive-icon foreground has been created from this raster artwork.
- Do not upscale small exports for print. A true vector master should be commissioned or recreated as editable vector artwork if needed.
- The palette in the artwork is visually approximate; sample exact brand colors from the final approved master before formal brand-system adoption.
- The PWA manifest assumes icons are served from `/icons/`. Adjust paths to match the deployed site's public asset directory.

## Suggested use
- Favicon: use `web/icons/favicon.ico`.
- iOS web clip: use `web/icons/apple-touch-icon.png`.
- PWA: use the supplied manifest and 192/512 icons.
- Social profile: use `social/profile-avatar-1024.png`.
- Social preview: use `social/og-image-1200x630.jpg`.
